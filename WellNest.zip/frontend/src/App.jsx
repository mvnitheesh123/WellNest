import { Link } from "react-router-dom";
export default function App() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <div className="p-8 bg-white shadow rounded-lg max-w-md">
        <h1 className="text-2xl font-bold mb-4">WellNest</h1>
        <p className="mb-6">Health & Wellness Tracking System</p>
        <div className="flex gap-4">
          <Link to="/login" className="px-4 py-2 bg-blue-600 text-white rounded">Login</Link>
          <Link to="/signup" className="px-4 py-2 border rounded">Sign up</Link>
        </div>
      </div>
    </div>
  );
}
