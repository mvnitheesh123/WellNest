import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import API, { setAuthToken } from "../api";
import AppointmentBook from "../components/AppointmentBook";
import HealthTracker from "../components/HealthTracker";
import RecordUploader from "../components/RecordUploader";
export default function Dashboard() {
  const nav = useNavigate();
  const token = localStorage.getItem("wn_access");
  useEffect(()=>{ if(!token) nav("/login"); else setAuthToken(token); }, []);
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-4 rounded shadow"><AppointmentBook /></div>
        <div className="bg-white p-4 rounded shadow"><HealthTracker /></div>
      </div>
      <div className="mt-6 bg-white p-4 rounded shadow"><RecordUploader /></div>
    </div>
  );
}
