import { useState } from "react";
import API, { setAuthToken } from "../api";
import { useNavigate } from "react-router-dom";
export default function Login() {
  const [form, setForm] = useState({ username: "", password: "" });
  const nav = useNavigate();
  const submit = async (e) => {
    e.preventDefault();
    try {
      const r = await API.post("auth/token/", form);
      const token = r.data.access;
      localStorage.setItem("wn_access", token);
      setAuthToken(token);
      nav("/dashboard");
    } catch (err) {
      console.error(err);
      alert("Login failed");
    }
  };
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <form onSubmit={submit} className="bg-white p-6 rounded shadow max-w-sm w-full">
        <h2 className="text-xl font-semibold mb-4">Login</h2>
        <input className="mb-2 w-full p-2 border" placeholder="Username" value={form.username} onChange={e=>setForm({...form, username:e.target.value})} />
        <input type="password" className="mb-4 w-full p-2 border" placeholder="Password" value={form.password} onChange={e=>setForm({...form, password:e.target.value})} />
        <button className="w-full py-2 bg-blue-600 text-white rounded">Login</button>
      </form>
    </div>
  );
}
