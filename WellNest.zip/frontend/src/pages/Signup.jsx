import { useState } from "react";
import API from "../api";
import { useNavigate } from "react-router-dom";
export default function Signup() {
  const [form, setForm] = useState({ username: "", email: "", password: "" });
  const nav = useNavigate();
  const submit = async (e) => {
    e.preventDefault();
    try {
      await API.post("signup/", form);
      alert("Signed up — now login");
      nav("/login");
    } catch (err) {
      console.error(err);
      alert("Error signing up");
    }
  };
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <form onSubmit={submit} className="bg-white p-6 rounded shadow max-w-sm w-full">
        <h2 className="text-xl font-semibold mb-4">Sign up</h2>
        <input className="mb-2 w-full p-2 border" placeholder="Username" value={form.username} onChange={e=>setForm({...form, username:e.target.value})} />
        <input className="mb-2 w-full p-2 border" placeholder="Email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} />
        <input type="password" className="mb-4 w-full p-2 border" placeholder="Password" value={form.password} onChange={e=>setForm({...form, password:e.target.value})} />
        <button className="w-full py-2 bg-blue-600 text-white rounded">Sign up</button>
      </form>
    </div>
  );
}
