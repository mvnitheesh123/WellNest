import { useEffect, useState } from "react";
import API from "../api";
export default function HealthTracker() {
  const [vitals, setVitals] = useState([]);
  useEffect(()=> {
    API.get("vitals/").then(r => setVitals(r.data)).catch(()=>setVitals([]));
  }, []);
  return (
    <div>
      <h3 className="text-lg font-semibold mb-2">Vitals</h3>
      <table className="w-full border">
        <thead><tr><th>Date</th><th>Weight (kg)</th><th>BP</th><th>Sugar</th></tr></thead>
        <tbody>
          {vitals.map(v => (
            <tr key={v.id}>
              <td>{new Date(v.recorded_at).toLocaleString()}</td>
              <td>{v.weight_kg || "-"}</td>
              <td>{v.systolic ? `${v.systolic}/${v.diastolic}` : "-"}</td>
              <td>{v.blood_sugar || "-"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
