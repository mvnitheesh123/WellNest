import { useEffect, useState } from "react";
import API from "../api";
export default function AppointmentBook() {
  const [doctors, setDoctors] = useState([]);
  const [doctor, setDoctor] = useState("");
  const [dateTime, setDateTime] = useState("");
  useEffect(()=> {
    API.get("profiles/?is_doctor=true").then(r=>setDoctors(r.data)).catch(()=>setDoctors([]));
  }, []);
  const book = async () => {
    try {
      await API.post("appointments/", { doctor, scheduled_at: dateTime });
      alert("Appointment booked");
    } catch (err) {
      console.error(err);
      alert("Error booking");
    }
  };
  return (
    <div>
      <h3 className="text-lg font-semibold mb-2">Book Appointment</h3>
      <select className="mb-2 w-full p-2 border" onChange={e => setDoctor(e.target.value)}>
        <option value="">Select doctor</option>
        {doctors.map(d => <option key={d.id} value={d.id}>{d.user.first_name || d.user.username} {d.user.last_name}</option>)}
      </select>
      <input type="datetime-local" className="mb-2 w-full p-2 border" value={dateTime} onChange={e=>setDateTime(e.target.value)} />
      <button className="px-4 py-2 bg-green-600 text-white rounded" onClick={book}>Book</button>
    </div>
  );
}
