import { useState } from "react";
import API from "../api";
export default function RecordUploader() {
  const [title, setTitle] = useState("");
  const [file, setFile] = useState(null);
  const submit = async (e) => {
    e.preventDefault();
    if (!file) return alert("Choose a file");
    const fd = new FormData();
    fd.append("title", title);
    fd.append("file", file);
    try {
      await API.post("records/", fd, { headers: { "Content-Type": "multipart/form-data" } });
      alert("Uploaded");
      setTitle(""); setFile(null);
    } catch (err) {
      console.error(err); alert("Upload failed");
    }
  };
  return (
    <div>
      <h3 className="text-lg font-semibold mb-2">Upload Health Record</h3>
      <form onSubmit={submit}>
        <input placeholder="Title" className="mb-2 w-full p-2 border" value={title} onChange={e=>setTitle(e.target.value)} />
        <input type="file" className="mb-2" onChange={e=>setFile(e.target.files[0])} />
        <button className="px-4 py-2 bg-indigo-600 text-white rounded">Upload</button>
      </form>
    </div>
  );
}
