# WellNest - Fullstack Starter (Django + React)

## Quick start (local)

### Backend
1. cd backend
2. python -m venv venv
3. source venv/bin/activate   # Windows: venv\Scripts\activate
4. pip install -r requirements.txt
5. python manage.py makemigrations
6. python manage.py migrate
7. python manage.py createsuperuser
8. python manage.py runserver

API base: http://127.0.0.1:8000/api/

### Frontend
1. cd frontend
2. npm install
3. npm run dev
Open http://localhost:5173

## Notes
- Login at /login, signup at /signup
- After login, token stored in localStorage key 'wn_access'
