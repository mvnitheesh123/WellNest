from django.conf import settings
from django.db import models
from django.utils import timezone
User = settings.AUTH_USER_MODEL
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    is_doctor = models.BooleanField(default=False)
    phone = models.CharField(max_length=20, blank=True)
    city = models.CharField(max_length=100, blank=True)
    about = models.TextField(blank=True)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    def __str__(self):
        return f"{self.user.username} ({'Doctor' if self.is_doctor else 'Patient'})"
class Appointment(models.Model):
    STATUS_CHOICES = [("SCHEDULED","SCHEDULED"),("CANCELLED","CANCELLED"),("COMPLETED","COMPLETED")]
    patient = models.ForeignKey(Profile, on_delete=models.CASCADE, related_name="patient_appointments")
    doctor = models.ForeignKey(Profile, on_delete=models.CASCADE, related_name="doctor_appointments")
    scheduled_at = models.DateTimeField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="SCHEDULED")
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    telemedicine_url = models.URLField(blank=True)
class HealthRecord(models.Model):
    owner = models.ForeignKey(Profile, on_delete=models.CASCADE, related_name="health_records")
    title = models.CharField(max_length=200)
    file = models.FileField(upload_to="records/")
    uploaded_at = models.DateTimeField(auto_now_add=True)
    notes = models.TextField(blank=True)
    date_of_record = models.DateField(default=timezone.now)
class Vital(models.Model):
    owner = models.ForeignKey(Profile, on_delete=models.CASCADE, related_name="vitals")
    recorded_at = models.DateTimeField(default=timezone.now)
    weight_kg = models.FloatField(null=True, blank=True)
    height_cm = models.FloatField(null=True, blank=True)
    systolic = models.IntegerField(null=True, blank=True)
    diastolic = models.IntegerField(null=True, blank=True)
    blood_sugar = models.FloatField(null=True, blank=True)
    notes = models.TextField(blank=True)
