from rest_framework import viewsets, permissions, status
from rest_framework.decorators import api_view, action
from rest_framework.response import Response
from django.contrib.auth import get_user_model
from .serializers import ProfileSerializer, AppointmentSerializer, HealthRecordSerializer, VitalSerializer, SignUpSerializer, UserSerializer
from .models import Profile, Appointment, HealthRecord, Vital
User = get_user_model()
@api_view(["POST"])
def signup(request):
    serializer = SignUpSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    user = serializer.save()
    return Response(UserSerializer(user).data, status=status.HTTP_201_CREATED)
@api_view(["GET"])
def health_check(request):
    return Response({"message":"WellNest Backend is Alive ✅"})
class ProfileViewSet(viewsets.ModelViewSet):
    queryset = Profile.objects.select_related("user").all()
    serializer_class = ProfileSerializer
    permission_classes = [permissions.IsAuthenticated]
    def get_queryset(self):
        qs = super().get_queryset()
        q = self.request.query_params.get("is_doctor")
        if q is not None:
            if q.lower() in ["true","1"]:
                return qs.filter(is_doctor=True)
            else:
                return qs.filter(is_doctor=False)
        return qs
class AppointmentViewSet(viewsets.ModelViewSet):
    queryset = Appointment.objects.all()
    serializer_class = AppointmentSerializer
    permission_classes = [permissions.IsAuthenticated]
    def perform_create(self, serializer):
        profile = self.request.user.profile
        serializer.save(patient=profile)
    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        appt = self.get_object()
        appt.status = "CANCELLED"
        appt.save()
        return Response({"status":"cancelled"})
class HealthRecordViewSet(viewsets.ModelViewSet):
    queryset = HealthRecord.objects.all()
    serializer_class = HealthRecordSerializer
    permission_classes = [permissions.IsAuthenticated]
    def perform_create(self, serializer):
        serializer.save(owner=self.request.user.profile)
class VitalViewSet(viewsets.ModelViewSet):
    queryset = Vital.objects.all()
    serializer_class = VitalSerializer
    permission_classes = [permissions.IsAuthenticated]
    def perform_create(self, serializer):
        serializer.save(owner=self.request.user.profile)
