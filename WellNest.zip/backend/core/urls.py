from rest_framework.routers import DefaultRouter
from django.urls import path, include
from .views import ProfileViewSet, AppointmentViewSet, HealthRecordViewSet, VitalViewSet, signup, health_check
router = DefaultRouter()
router.register("profiles", ProfileViewSet)
router.register("appointments", AppointmentViewSet)
router.register("records", HealthRecordViewSet)
router.register("vitals", VitalViewSet)
urlpatterns = [
    path("", include(router.urls)),
    path("signup/", signup),
    path("status/", health_check),
]
