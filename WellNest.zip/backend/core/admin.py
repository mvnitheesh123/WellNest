from django.contrib import admin
from .models import Profile, Appointment, HealthRecord, Vital
admin.site.register(Profile)
admin.site.register(Appointment)
admin.site.register(HealthRecord)
admin.site.register(Vital)
